import { useEffect, useCallback } from "react";
import { useSelector, useDispatch } from "react-redux";
import { setMessages } from "../redux/messageSlice";
import { getSocket } from "../services/socketService";
import toast from 'react-hot-toast';

const useGetRealTimeMessage = () => {
    const { connected } = useSelector(store => store.socket);
    const { messages } = useSelector(store => store.message);
    const { selectedUser } = useSelector(store => store.user);
    const dispatch = useDispatch();

    const handleNewMessage = useCallback((newMessage) => {
        if (!newMessage) return;
        
        // Only update messages if they're from/to the currently selected user
        if (selectedUser && 
            (newMessage.senderId === selectedUser._id || 
             newMessage.receiverId === selectedUser._id)) {
            const currentMessages = Array.isArray(messages) ? messages : [];
            dispatch(setMessages([...currentMessages, newMessage]));
        }
    }, [messages, selectedUser, dispatch]);

    useEffect(() => {
        const socket = getSocket();
        if (!socket || !connected) {
            if (!connected) {
                console.log('Socket not connected');
            }
            return;
        }

        socket.on("newMessage", handleNewMessage);
        
        socket.on("connect", () => {
            console.log('Socket connected');
        });

        socket.on("connect_error", (error) => {
            console.error('Socket connection error:', error);
            toast.error('Connection to chat server failed');
        });

        return () => {
            socket.off("newMessage", handleNewMessage);
            socket.off("connect");
            socket.off("connect_error");
        };
    }, [connected, handleNewMessage]);
};

export default useGetRealTimeMessage;