import io from 'socket.io-client';
import store from '../redux/store';
import { setSocketConnected } from '../redux/socketSlice';
import { API_CONFIG } from '../config/config';

let socket = null;

export const initSocket = (userId) => {
    if (socket) return socket;

    socket = io(API_CONFIG.BASE_URL, {
        query: { userId },
        withCredentials: true,
        transports: ['websocket', 'polling'],
        forceNew: true
    });

    socket.on('connect', () => {
        store.dispatch(setSocketConnected(true));
    });

    socket.on('disconnect', () => {
        store.dispatch(setSocketConnected(false));
    });

    return socket;
};

export const getSocket = () => socket;

export const disconnectSocket = () => {
    if (socket) {
        socket.disconnect();
        socket = null;
        store.dispatch(setSocketConnected(false));
    }
};