import { createSlice } from "@reduxjs/toolkit";

const socketSlice = createSlice({
    name: "socket",
    initialState: {
        connected: false,
        userId: null
    },
    reducers: {
        setSocketConnected: (state, action) => {
            state.connected = action.payload;
        },
        setUserId: (state, action) => {
            state.userId = action.payload;
        }
    }
});

export const { setSocketConnected, setUserId } = socketSlice.actions;
export default socketSlice.reducer;