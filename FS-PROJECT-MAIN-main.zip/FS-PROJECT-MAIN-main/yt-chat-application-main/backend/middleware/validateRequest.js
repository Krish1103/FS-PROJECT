export const validateRegisterRequest = (req, res, next) => {
    const { fullName, username, password, confirmPassword, gender } = req.body;
    
    // Check if all required fields are present
    if (!fullName || !username || !password || !confirmPassword || !gender) {
        return res.status(400).json({ 
            success: false,
            message: "All fields are required" 
        });
    }

    // Validate fullName (at least 2 characters, only letters and spaces)
    if (!/^[A-Za-z\s]{2,}$/.test(fullName)) {
        return res.status(400).json({
            success: false,
            message: "Full name must contain at least 2 characters and only letters and spaces"
        });
    }

    // Validate username (3-20 characters, letters, numbers, underscores)
    if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) {
        return res.status(400).json({
            success: false,
            message: "Username must be 3-20 characters long and contain only letters, numbers, and underscores"
        });
    }

    // Validate password (min 6 chars, at least one number and one letter)
    if (!/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/.test(password)) {
        return res.status(400).json({
            success: false,
            message: "Password must be at least 6 characters long and contain at least one letter and one number"
        });
    }

    // Validate password confirmation
    if (password !== confirmPassword) {
        return res.status(400).json({
            success: false,
            message: "Passwords do not match"
        });
    }

    // Validate gender
    if (!['male', 'female'].includes(gender)) {
        return res.status(400).json({
            success: false,
            message: "Gender must be either 'male' or 'female'"
        });
    }

    next();
};

export const validateLoginRequest = (req, res, next) => {
    const { username, password } = req.body;

    // Check if all required fields are present
    if (!username || !password) {
        return res.status(400).json({
            success: false,
            message: "Username and password are required"
        });
    }

    // Validate username format
    if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) {
        return res.status(400).json({
            success: false,
            message: "Invalid username format"
        });
    }

    // Basic password length check (detailed validation done at registration)
    if (password.length < 6) {
        return res.status(400).json({
            success: false,
            message: "Invalid password format"
        });
    }

    next();
};